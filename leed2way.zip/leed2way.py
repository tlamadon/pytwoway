import numpy as np
import pandas as pd
import pytwoway as tw
import bipartitepandas as bpd
from sfi import Data, Scalar

def run_ho(coli="i", colj="j", coly="y", colt="t"):

	print("Running homoskedastic correction")

	col_i = np.array( Data.get( coli ) )
	col_j = np.array( Data.get( colj ) )
	col_y = np.array( Data.get( coly ) )
	col_t = np.array( Data.get( colt ) )

	# create the bipartite data
	bdf = bpd.BipartiteDataFrame(
		i=col_i, j=col_j, y=col_y, t=col_t
	)

	# clean the data
	clean_params = bpd.clean_params(
		{
			'connectedness': 'connected',
			'collapse_at_connectedness_measure': True,
			'drop_single_stayers': True,
			'drop_returns': 'returners',
			'copy': False,
			'verbose': False
		}
	)
	bdf = bdf.clean(clean_params)

	# Initialize FE estimator
	fe_params = tw.fe_params(
		{
			'he': False,
			'ncore': 2,
			'progress_bars':False
		}
	)
	fe_estimator = tw.FEEstimator(bdf, fe_params)

	# Fit FE estimator
	fe_estimator.fit()

 	#print(fe_estimator.summary)
	
	Scalar.setValue("var_y", fe_estimator.summary["var(y)"])
	Scalar.setValue("var_psi_fe", fe_estimator.summary["var(psi)_fe"])
	Scalar.setValue("cov_alpha_psi_fe", fe_estimator.summary["cov(psi, alpha)_fe"])
	Scalar.setValue("var_psi_ho", fe_estimator.summary["var(psi)_ho"])
	Scalar.setValue("cov_alpha_psi_ho", fe_estimator.summary["cov(psi, alpha)_ho"])
	
	
